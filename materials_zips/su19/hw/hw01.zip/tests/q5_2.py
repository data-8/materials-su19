test = {
  'name': 'Question 5_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(smallest_change_major, (int, float))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> smallest_change_major
          1
          """,
          'hidden': True,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
