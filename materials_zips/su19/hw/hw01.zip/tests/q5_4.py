test = {
  'name': 'Question 5_4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(biggest_rel_change_major, (int, float))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> biggest_rel_change_major
          1
          """,
          'hidden': True,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
