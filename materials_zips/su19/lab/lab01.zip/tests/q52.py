test = {
  'name': 'q52',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> secret_number
          42
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
